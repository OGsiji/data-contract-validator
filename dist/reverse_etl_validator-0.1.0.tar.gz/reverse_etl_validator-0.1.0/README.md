# What the Reverse ETL Validator Actually Does

## 🔍 **Core Function: Schema Extraction + Comparison**

The tool extracts schemas from **both sides** and compares them:

```
DBT Models          Reverse ETL         FastAPI Models
(What data          Validator           (What APIs
 produces)          ↕️ COMPARES ↕️        expect)
     ↓                   ↓                   ↓
   Schema              Finds              Schema
 Extraction          Mismatches         Extraction
```

## 📊 **Step 1: Extract Schema from DBT Models**

### What it extracts from DBT:
```sql
-- dbt_project/models/marts/user_analytics.sql
select
    user_id,
    email,
    total_orders,
    avg_order_value,
    last_login_at,
    is_premium
from {{ ref('stg_users') }}
```

### Tool extracts this schema:
```yaml
# Extracted DBT schema
user_analytics:
  columns:
    - name: user_id
      type: varchar
      nullable: false
    - name: email  
      type: varchar
      nullable: false
    - name: total_orders
      type: integer
      nullable: false
    - name: avg_order_value
      type: float
      nullable: true
    - name: last_login_at
      type: timestamp
      nullable: true
    - name: is_premium
      type: boolean
      nullable: false
```

### How it extracts DBT schemas:
```python
class DBTExtractor:
    def extract_schema(self, dbt_project_path: str) -> Dict[str, Any]:
        # Method 1: Parse dbt manifest.json (after dbt compile)
        manifest = self._load_dbt_manifest()
        
        # Method 2: Parse SQL files directly (faster for CI)
        sql_files = self._find_sql_files(dbt_project_path)
        
        schemas = {}
        for model_file in sql_files:
            # Extract column names from SELECT statement
            columns = self._parse_select_columns(model_file)
            model_name = Path(model_file).stem
            schemas[model_name] = {'columns': columns}
        
        return schemas
    
    def _parse_select_columns(self, sql_file: str) -> List[Dict]:
        """Parse SQL to extract column names and infer types"""
        with open(sql_file) as f:
            sql = f.read()
        
        # Find final SELECT statement
        select_match = re.search(r'select\s+(.*?)\s+from', sql, re.DOTALL | re.IGNORECASE)
        columns_text = select_match.group(1)
        
        columns = []
        for col in columns_text.split(','):
            col = col.strip()
            # Handle different patterns:
            # - "user_id" -> user_id
            # - "u.user_id" -> user_id  
            # - "count(*) as total_orders" -> total_orders
            # - "case when ... end as is_premium" -> is_premium
            
            column_name = self._extract_column_name(col)
            column_type = self._infer_column_type(col)
            
            columns.append({
                'name': column_name,
                'type': column_type,
                'nullable': self._infer_nullable(col)
            })
        
        return columns
```

## 🚀 **Step 2: Extract Schema from FastAPI Models**

### What it extracts from FastAPI:
```python
# app/models/user.py
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class UserAnalytics(BaseModel):
    user_id: str                           # Required field
    email: str                            # Required field  
    total_orders: int                     # Required field
    avg_order_value: Optional[float]      # Optional field
    last_login_at: Optional[datetime]     # Optional field
    is_premium: bool                      # Required field
    # Missing: total_revenue (not in DBT!)
    total_revenue: float                  # This will cause an error!
```

### Tool extracts this schema:
```yaml
# Extracted FastAPI schema  
UserAnalytics:
  table_name: user_analytics  # Inferred from class name
  columns:
    - name: user_id
      type: varchar
      required: true        # No Optional[] wrapper
    - name: email
      type: varchar  
      required: true
    - name: total_orders
      type: integer
      required: true
    - name: avg_order_value
      type: float
      required: false       # Optional[] = not required
    - name: last_login_at
      type: timestamp
      required: false
    - name: is_premium
      type: boolean
      required: true  
    - name: total_revenue    # ⚠️ REQUIRED but not in DBT!
      type: float
      required: true
```

### How it extracts FastAPI schemas:
```python
class FastAPIExtractor:
    def extract_schema(self, models_module: str) -> Dict[str, Any]:
        # Import the models module
        module = importlib.import_module(models_module)  # app.models
        
        schemas = {}
        
        # Find all Pydantic models
        for name, obj in inspect.getmembers(module):
            if (inspect.isclass(obj) and 
                issubclass(obj, BaseModel) and 
                obj != BaseModel):
                
                # Extract fields from Pydantic model
                model_schema = self._analyze_pydantic_model(obj)
                schemas[name] = model_schema
        
        return schemas
    
    def _analyze_pydantic_model(self, model_class) -> Dict[str, Any]:
        """Extract fields and types from Pydantic model"""
        
        # Get model fields (Pydantic v2 way)
        model_fields = model_class.model_fields
        type_hints = get_type_hints(model_class)
        
        columns = []
        for field_name, field_info in model_fields.items():
            type_hint = type_hints[field_name]
            
            columns.append({
                'name': field_name,
                'type': self._python_to_sql_type(type_hint),  # str -> varchar
                'required': self._is_field_required(field_info, type_hint)
            })
        
        return {
            'table_name': self._infer_table_name(model_class),  # UserAnalytics -> user_analytics
            'columns': columns
        }
    
    def _is_field_required(self, field_info, type_hint) -> bool:
        """Check if field is required"""
        # Check for Optional[Type] or Union[Type, None]
        if hasattr(type_hint, '__origin__') and type_hint.__origin__ is Union:
            if type(None) in type_hint.__args__:
                return False  # Optional field
        
        # Check for default values
        if hasattr(field_info, 'default') and field_info.default is not ...:
            return False  # Has default = optional
            
        return True  # Required field
```

## ⚖️ **Step 3: Compare Schemas and Find Issues**

### The comparison finds these issues:
```python
def compare_schemas(dbt_schema: Dict, fastapi_schema: Dict) -> List[ValidationIssue]:
    """Compare DBT output vs FastAPI expectations"""
    
    issues = []
    
    # Get column lists
    dbt_columns = {col['name']: col for col in dbt_schema['columns']}
    api_columns = {col['name']: col for col in fastapi_schema['columns']}
    
    # 1. Check for missing columns (API expects but DBT doesn't provide)
    missing_in_dbt = set(api_columns.keys()) - set(dbt_columns.keys())
    for col_name in missing_in_dbt:
        api_col = api_columns[col_name]
        severity = ValidationSeverity.ERROR if api_col['required'] else ValidationSeverity.WARNING
        
        issues.append(ValidationIssue(
            severity=severity,
            table='user_analytics',
            column=col_name,
            message=f"FastAPI expects column '{col_name}' but DBT doesn't provide it",
            suggested_fix=f"Add '{col_name}' to your DBT model or remove from FastAPI model"
        ))
    
    # 2. Check for type mismatches
    common_columns = set(dbt_columns.keys()) & set(api_columns.keys())
    for col_name in common_columns:
        dbt_col = dbt_columns[col_name]
        api_col = api_columns[col_name]
        
        if not self._types_compatible(dbt_col['type'], api_col['type']):
            issues.append(ValidationIssue(
                severity=ValidationSeverity.WARNING,
                table='user_analytics', 
                column=col_name,
                message=f"Type mismatch: DBT provides '{dbt_col['type']}' but FastAPI expects '{api_col['type']}'",
                suggested_fix=f"Update FastAPI model to expect '{dbt_col['type']}' or fix DBT column type"
            ))
    
    # 3. Check for extra columns (DBT provides but API doesn't use)
    extra_in_dbt = set(dbt_columns.keys()) - set(api_columns.keys())
    for col_name in extra_in_dbt:
        issues.append(ValidationIssue(
            severity=ValidationSeverity.INFO,
            table='user_analytics',
            column=col_name, 
            message=f"DBT provides column '{col_name}' but FastAPI doesn't use it",
            suggested_fix="Consider adding to FastAPI model if needed"
        ))
    
    return issues
```

### Example validation results:
```
🔍 Contract Validation Results:

❌ CRITICAL ISSUES:
  💥 user_analytics.total_revenue: FastAPI expects this column but DBT doesn't provide it
     💡 Fix: Add 'total_revenue' to your DBT model or remove from UserAnalytics

⚠️  WARNINGS:  
  ⚠️  user_analytics.avg_order_value: Type mismatch - DBT provides 'float' but FastAPI expects 'decimal'
     💡 Fix: Update FastAPI model to use 'float' type

ℹ️  INFO:
  ℹ️  user_analytics.internal_score: DBT provides this column but FastAPI doesn't use it
     💡 Fix: Consider adding to FastAPI model if needed

🚫 VALIDATION FAILED - 1 critical issue blocks deployment
```

## 🔄 **Real-World Example: The Full Flow**

### 1. Developer Changes DBT Model:
```sql
-- Removes total_orders, adds total_revenue  
select
    user_id,
    email,
    -- total_orders,  ❌ REMOVED
    total_revenue,    ✅ ADDED
    avg_order_value,
    last_login_at,
    is_premium
from {{ ref('stg_users') }}
```

### 2. Pre-commit Hook Runs:
```bash
git commit -m "Update user analytics model"

# Tool extracts schemas:
# DBT: [user_id, email, total_revenue, avg_order_value, last_login_at, is_premium]  
# API: [user_id, email, total_orders, avg_order_value, last_login_at, is_premium]

# Comparison finds:
# - total_orders: Missing in DBT but required by API ❌
# - total_revenue: Added in DBT but not used by API ℹ️
```

### 3. Commit Blocked:
```
❌ Contract validation failed (2.1s)

  💥 user_analytics.total_orders: FastAPI requires this column but DBT removed it
     💡 Fix: Add 'total_orders' back to DBT model or update UserAnalytics model

🚫 Commit blocked - fix this issue first
```

### 4. Developer Fixes Issue:
```python
# Updates FastAPI model to match new DBT schema
class UserAnalytics(BaseModel):
    user_id: str
    email: str
    total_revenue: float    # ✅ Changed from total_orders
    avg_order_value: Optional[float]
    last_login_at: Optional[datetime]
    is_premium: bool
```

### 5. Commit Succeeds:
```bash
git add app/models/user.py
git commit -m "Update user analytics model" 

✅ Contract validation passed (1.8s)
[main abc123d] Update user analytics model
```

## 🎯 **Key Points**

### **Yes, it extracts from both:**
- ✅ **DBT models**: Parses SQL files or manifest.json to understand what columns/types are produced
- ✅ **FastAPI models**: Analyzes Pydantic classes to understand what columns/types are expected

### **The magic is in the comparison:**
- **Missing columns**: API expects it, DBT doesn't provide it → **BLOCKS DEPLOYMENT**  
- **Type mismatches**: varchar vs int → **WARNING**
- **Extra columns**: DBT provides it, API doesn't use it → **INFO**

### **It runs automatically:**
- **Pre-commit hook**: Prevents bad commits (5 seconds)
- **CI/CD pipeline**: Prevents bad merges (team protection)
- **Cross-repo notifications**: Coordinates between teams

**The tool is essentially a "schema contract enforcer" that prevents production API breaks by validating data pipeline outputs against API expectations!** 🛡️